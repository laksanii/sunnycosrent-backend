

<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Daftar Rental</h1>
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Daftar Rental
            </div>
            <div class="card-body table-responsive">
                Pilih tanggal:
                <form action="/rental" method="get">
                    <?php echo csrf_field(); ?>
                    <input type="date" name="start" id="start"> -
                    <input type="date" name="finish" id="finish">
                    <button class="btn btn-success btn-sm " type="submit">Cari</button>
                </form>
                <table id="dataTable" class="table nowrap pe-2 ">
                    <thead class="bg-success ">
                        <tr>
                            <th>Kode</th>
                            <th>Nama</th>
                            <th>Whatsapp</th>
                            <th>Instagram</th>
                            <th>Alamat</th>
                            <th>Kode Pos</th>
                            <th>Character</th>
                            <th>Rent Date</th>
                            <th>Ship Date</th>
                            <th>Status Pembayaran</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($order->code); ?></td>
                                <td><?php echo e($order->name); ?></td>
                                <td><?php echo e($order->whatsapp); ?></td>
                                <td><?php echo e($order->instagram); ?></td>
                                <td><?php echo e($order->address); ?></td>
                                <td><?php echo e($order->post_code); ?></td>
                                <td><?php echo e($order->costume->name); ?></td>
                                <td><?php echo e($order->rent_date); ?></td>
                                <td><?php echo e($order->ship_date); ?></td>
                                <td><?php echo e($order->payment_status); ?></td>
                                <td class="d-flex gap-2">
                                    <a class="btn btn-success btn-sm" href="/rental/<?php echo e($order->code); ?>">Detail</a>
                                    <?php if($order->payment_status != 'Cancel'): ?>
                                        <div>
                                            <form action="/cancel" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="id" value="<?php echo e($order->id); ?>">
                                                <button type="submit" class="btn btn-danger btn-sm">
                                                    <i class="fa-solid fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    <?php endif; ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\sunnycosrent-backend\resources\views/orders.blade.php ENDPATH**/ ?>