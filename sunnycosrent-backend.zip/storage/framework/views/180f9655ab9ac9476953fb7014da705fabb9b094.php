

<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Detail Kostum</h1>
        <div class="card mb-4">
            <div class="card-header">

                <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal"
                    class="btn btn-success btn-sm ms-auto">Edit</button>
            </div>
            <div class="card-body">
                <div class="col-12 mb-3 ">
                    <div class="row mb-1 gap-1 justify-content-center">
                        <div class="fw-bold col-4 bg-warning py-2 rounded">
                            Nama
                        </div>
                        <div class="col-7 bg-warning py-2 rounded">
                            <?php echo e($costume->name); ?>

                        </div>
                    </div>
                    <div class="row mb-1 gap-1 justify-content-center">
                        <div class="fw-bold col-4 bg-warning py-2 rounded">
                            Kategori
                        </div>
                        <div class="col-7 bg-warning py-2 rounded">
                            <?php echo e($costume->category->name); ?>

                        </div>
                    </div>
                    <div class="row mb-1 gap-1 justify-content-center">
                        <div class="fw-bold col-4 bg-warning py-2 rounded">
                            Sizes
                        </div>
                        <div class="col-7 bg-warning py-2 rounded">
                            <?php echo e($costume->sizes); ?>

                        </div>
                    </div>
                    <div class="row mb-1 gap-1 justify-content-center">
                        <div class="fw-bold col-4 bg-warning py-2 rounded">
                            LD, LP
                        </div>
                        <div class="col-7 bg-warning py-2 rounded">
                            <?php echo e($costume->ld); ?>, <?php echo e($costume->lp); ?>

                        </div>
                    </div>
                    <div class="row mb-1 gap-1 justify-content-center">
                        <div class="fw-bold col-4 bg-warning py-2 rounded">
                            Harga
                        </div>
                        <div class="col-7 bg-warning py-2 rounded">
                            <?php echo e($costume->price); ?>

                        </div>
                    </div>
                    <div class="row mb-1 gap-1 justify-content-center">
                        <div class="fw-bold col-4 bg-warning py-2 rounded">
                            Aksesoris
                        </div>
                        <div class="col-7 bg-warning py-2 rounded">
                            <?php if($costume->accessories->count() > 0): ?>
                                <ul>
                                    <?php $__currentLoopData = $costume->accessories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accessory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($accessory->name); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php else: ?>
                                Costume Tidak Punya Akseoris
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="Form" action="/costumes/<?php echo e($costume->id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="name" class="form-label">Nama Character</label>
                            <input type="text" class="form-control" id="name" name="name"
                                value="<?php echo e($costume->name); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="category_id" class="form-label">Kategori</label>
                            <select class="form-select" name="category_id" id="category_id"
                                aria-label="Default select example">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"
                                        <?php echo e($category->id == $costume->category_id ? 'selected' : ''); ?>>
                                        <?php echo e($category->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="sizes" class="form-label">Sizes</label>
                            <input type="text" class="form-control" id="sizes" name="sizes"
                                value="<?php echo e($costume->sizes); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="ld" class="form-label">LD</label>
                            <input type="text" class="form-control" id="ld" name="ld"
                                value="<?php echo e($costume->ld); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="lp" class="form-label">LP</label>
                            <input type="text" class="form-control" id="lp" name="lp"
                                value="<?php echo e($costume->lp); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="price" class="form-label">Harga</label>
                            <input type="text" class="form-control" id="price" name="price"
                                value="<?php echo e($costume->price); ?>">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" onclick="submitForm()">Simpan</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function submitForm() {
            const form = document.getElementById("Form");
            form.submit()
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\sunnycosrent-backend\resources\views/costume.blade.php ENDPATH**/ ?>