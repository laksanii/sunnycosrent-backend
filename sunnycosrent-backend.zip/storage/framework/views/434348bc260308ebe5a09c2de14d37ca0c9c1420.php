

<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Detail Rental</h1>
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Code: <?php echo e($order->code); ?>

            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-12 col-lg-8 mb-3 ">
                        <div class="row mb-1 gap-1 justify-content-center">
                            <div class="fw-bold col-4 bg-warning py-2 rounded">
                                Nama
                            </div>
                            <div class="col-7 bg-warning py-2 rounded">
                                <?php echo e($order->name); ?>

                            </div>
                        </div>
                        <div class="row mb-1 gap-1 justify-content-center">
                            <div class="fw-bold col-4 bg-warning py-2 rounded">
                                email
                            </div>
                            <div class="col-7 bg-warning py-2 rounded">
                                <?php echo e($order->email); ?>

                            </div>
                        </div>
                        <div class="row mb-1 gap-1 justify-content-center">
                            <div class="fw-bold col-4 bg-warning py-2 rounded">
                                whatsapp
                            </div>
                            <div class="col-7 bg-warning py-2 rounded">
                                <?php echo e($order->whatsapp); ?>

                            </div>
                        </div>
                        <div class="row mb-1 gap-1 justify-content-center">
                            <div class="fw-bold col-4 bg-warning py-2 rounded">
                                instagram
                            </div>
                            <div class="col-7 bg-warning py-2 rounded">
                                <?php echo e($order->instagram); ?>

                            </div>
                        </div>
                        <div class="row mb-1 gap-1 justify-content-center">
                            <div class="fw-bold col-4 bg-warning py-2 rounded">
                                Alamat Lengkap
                            </div>
                            <div class="col-7 bg-warning py-2 rounded">
                                <?php echo e($order->address); ?>

                            </div>
                        </div>
                        <div class="row mb-1 gap-1 justify-content-center">
                            <div class="fw-bold col-4 bg-warning py-2 rounded">
                                Kode Pos
                            </div>
                            <div class="col-7 bg-warning py-2 rounded">
                                <?php echo e($order->post_code); ?>

                            </div>
                        </div>
                        <div class="row mb-1 gap-1 justify-content-center">
                            <div class="fw-bold col-4 bg-warning py-2 rounded">
                                Kostum (Nama Character)
                            </div>
                            <div class="col-7 bg-warning py-2 rounded">
                                <?php echo e($order->costume->name); ?>

                            </div>
                        </div>
                        <div class="row mb-1 gap-1 justify-content-center">
                            <div class="fw-bold col-4 bg-warning py-2 rounded">
                                Tanggal Rental
                            </div>
                            <div class="col-7 bg-warning py-2 rounded">
                                <?php echo e($order->rent_date); ?>

                            </div>
                        </div>
                        <div class="row mb-1 gap-1 justify-content-center">
                            <div class="fw-bold col-4 bg-warning py-2 rounded">
                                Tanggal Pengiriman
                            </div>
                            <div class="col-7 bg-warning py-2 rounded">
                                <?php echo e($order->ship_date); ?>

                            </div>
                        </div>
                        <div class="row mb-1 gap-1 justify-content-center">
                            <div class="fw-bold col-4 bg-warning py-2 rounded">
                                Pembayaran
                            </div>
                            <div class="col-7 bg-warning py-2 rounded">
                                <?php echo e($order->payment); ?>

                            </div>
                        </div>
                        <div class="row mb-1 gap-1 justify-content-center">
                            <div class="fw-bold col-4 bg-warning py-2 rounded">
                                Status Pembayaran
                            </div>
                            <div class="col-7 bg-warning py-2 rounded">
                                <?php echo e($order->payment_status); ?>

                            </div>
                        </div>
                        <div class="row mb-1 gap-1 justify-content-center">
                            <div class="fw-bold col-4 bg-warning py-2 rounded">
                                DP
                            </div>
                            <div class="col-7 bg-warning py-2 rounded">
                                Rp <?php echo e(number_format($order->DP, 0, ',', '.')); ?>

                            </div>
                        </div>
                        <div class="row mb-1 gap-1 justify-content-center">
                            <div class="fw-bold col-4 bg-warning py-2 rounded">
                                Total Harga
                            </div>
                            <div class="col-7 bg-warning py-2 rounded">
                                Rp <?php echo e(number_format($order->total_price, 0, ',', '.')); ?>

                            </div>
                        </div>
                        <div class="row mb-1 gap-1 justify-content-center">
                            <div class="fw-bold col-4 bg-warning py-2 rounded">
                                Aksesoris
                            </div>
                            <div class="col-7 bg-warning py-2 rounded">
                                <?php if($order->order_accessories->count() < 1): ?>
                                    Tidak pakai aksesoris
                                <?php else: ?>
                                    <ul>
                                        <?php $__currentLoopData = $order->order_accessories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accessory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($accessory->name); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4 ">
                        <div class="d-flex flex-column align-items-center fw-bold">
                            Bukti Transfer
                            <div class="pict-wraper border border-2 mb-2">
                                <img src="<?php echo e(Storage::url($order->payment_pict)); ?>" class="pict payment-pict"
                                    alt="Foto">
                            </div>
                            Foto KTP/KK/Kartu Pelajar
                            <div class="pict-wraper border border-2 mb-2">
                                <img src="<?php echo e(Storage::url($order->KTP_pict)); ?>" class="pict payment-pict" alt="Foto">
                            </div>
                            Foto Selfie
                            <div class="pict-wraper border border-2 mb-2">
                                <img src="<?php echo e(Storage::url($order->KTP_selfie)); ?>" class="pict payment-pict" alt="Foto">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card mb-4 picts-box">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Bukti Konfirmasi Diterima
            </div>
            <div class="card-body">
                <div class="row">
                    <?php $__currentLoopData = $order->confirm_pict; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pict): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-6 mb-3">
                            <img src="<?php echo e(Storage::url($pict->path)); ?>" alt="confirm_pict" style="width: 100%">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="card mb-4 picts-box">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Bukti Pengembalian
            </div>
            <div class="card-body">
                <div class="row">
                    <?php $__currentLoopData = $order->return_pict; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pict): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-6 mb-3">
                            <img src="<?php echo e(Storage::url($pict->path)); ?>" alt="confirm_pict" style="width: 100%">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\sunnycosrent-backend\resources\views/order.blade.php ENDPATH**/ ?>