

<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Daftar Rental Belum Dikirim</h1>
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Daftar Rental Belum Dikirim
            </div>
            <div class="card-body table-responsive">
                <table id="dataTable" class="table nowrap pe-2 ">
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Nama</th>
                            <th>Whatsapp</th>
                            <th>Instagram</th>
                            <th>Alamat</th>
                            <th>Kode Pos</th>
                            <th>Character</th>
                            <th>Rent Date</th>
                            <th>Ship Date</th>
                            <th>Status Pengiriman</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($order->code); ?></td>
                                <td><?php echo e($order->name); ?></td>
                                <td><?php echo e($order->whatsapp); ?></td>
                                <td><?php echo e($order->instagram); ?></td>
                                <td><?php echo e($order->address); ?></td>
                                <td><?php echo e($order->post_code); ?></td>
                                <td><?php echo e($order->costume->name); ?></td>
                                <td><?php echo e($order->rent_date); ?></td>
                                <td><?php echo e($order->ship_date); ?></td>
                                <td><?php echo e($order->shipping_status); ?></td>
                                <td>
                                    <a class="btn btn-success btn-sm" href="/rental/<?php echo e($order->code); ?>">Detail</a>
                                    <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#modal"
                                        onclick="sendData('<?php echo e($order->code); ?>')">Sudah
                                        dikirim</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Kostum</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="Form" action="/kirim" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="code" class="form-label">Kode Order</label>
                            <input type="text" class="form-control" id="code" name="code" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="shipping_status" class="form-label">Resi</label>
                            <input type="text" class="form-control" id="shipping_status" name="shipping_status">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kembali</button>
                    <button type="button" onclick="submitForm()" class="btn btn-success">Tambah</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function sendData(code) {
            const input = document.getElementById("code")
            input.value = code

        }

        function submitForm() {
            const form = document.getElementById("Form")
            form.submit()
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\sunnycosrent-backend\resources\views/ordersNotShipYet.blade.php ENDPATH**/ ?>