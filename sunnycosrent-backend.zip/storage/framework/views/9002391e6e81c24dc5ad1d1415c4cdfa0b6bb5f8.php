

<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Daftar Kostum Booked</h1>
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Daftar Kostum Booked
            </div>
            <div class="card-body table-responsive">
                Pilih tanggal:
                <form action="/costumes-booked" method="get">
                    <?php echo csrf_field(); ?>

                    <input type="date" name="start" id="start"> -
                    <input type="date" name="finish" id="finish">
                    <button class="btn btn-success btn-sm " type="submit">Cari</button>
                </form>
                <table id="dataTable" class="table">
                    <thead>
                        <tr>
                            <th>Nama Character</th>
                            <th>Harga</th>
                            <th>Size</th>
                            <th>LD</th>
                            <th>LP</th>
                            <th>Kategori</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $costumes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $costume): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($costume->name); ?></td>
                                <td>Rp <?php echo e(number_format($costume->price, 0, ',', '.')); ?></td>
                                <td><?php echo e($costume->sizes); ?></td>
                                <td><?php echo e($costume->ld); ?></td>
                                <td><?php echo e($costume->lp); ?></td>
                                <td><?php echo e($costume->category); ?></td>
                                <td>
                                    <div class="btn btn-success btn-sm">Edit</div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\sunnycosrent-backend\resources\views/costumesBook.blade.php ENDPATH**/ ?>