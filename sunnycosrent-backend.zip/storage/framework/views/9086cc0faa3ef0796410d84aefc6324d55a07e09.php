

<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Daftar Rental Sudah Dikirim</h1>
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Daftar Rental Sudah Dikirim
            </div>
            <div class="card-body table-responsive">
                <table id="dataTable" class="table nowrap pe-2 ">
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Nama</th>
                            <th>Whatsapp</th>
                            <th>Instagram</th>
                            <th>Alamat</th>
                            <th>Kode Pos</th>
                            <th>Character</th>
                            <th>Rent Date</th>
                            <th>Ship Date</th>
                            <th>Status Pengiriman</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($order->code); ?></td>
                                <td><?php echo e($order->name); ?></td>
                                <td><?php echo e($order->whatsapp); ?></td>
                                <td><?php echo e($order->instagram); ?></td>
                                <td><?php echo e($order->address); ?></td>
                                <td><?php echo e($order->post_code); ?></td>
                                <td><?php echo e($order->costume->name); ?></td>
                                <td><?php echo e($order->rent_date); ?></td>
                                <td><?php echo e($order->ship_date); ?></td>
                                <td><?php echo e($order->shipping_status); ?></td>
                                <td>
                                    <a class="btn btn-success btn-sm" href="/rental/<?php echo e($order->code); ?>">Detail</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\sunnycosrent-backend\resources\views/ordersAlreadyShip.blade.php ENDPATH**/ ?>