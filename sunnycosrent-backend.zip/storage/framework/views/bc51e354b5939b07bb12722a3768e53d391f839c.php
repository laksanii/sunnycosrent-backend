<nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
    <div class="sb-sidenav-menu">
        <div class="nav">

            <div class="sb-sidenav-menu-heading">Kostum</div>

            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#kostum"
                aria-expanded="false" aria-controls="collapseLayouts">
                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                Daftar Kostum
                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
            </a>
            <div class="collapse" id="kostum" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                <nav class="sb-sidenav-menu-nested nav">
                    <a class="nav-link" href="/costumes">Semua Kostum</a>
                    <a class="nav-link" href="/costumes-available">Available</a>
                    <a class="nav-link" href="/costumes-booked">Booked</a>
                </nav>
            </div>

            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#acc"
                aria-expanded="false" aria-controls="collapseLayouts">
                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                Daftar Aksesories
                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
            </a>
            <div class="collapse" id="acc" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                <nav class="sb-sidenav-menu-nested nav">
                    <a class="nav-link" href="/accessories">Semua Aksesories</a>
                </nav>
            </div>

            <div class="sb-sidenav-menu-heading">Rental</div>

            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts"
                aria-expanded="false" aria-controls="collapseLayouts">
                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                Daftar Rental
                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
            </a>
            <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                <nav class="sb-sidenav-menu-nested nav">
                    <a class="nav-link" href="/rental">Semua Rental</a>
                    <a class="nav-link" href="/rental-sudah-dikirim">Sudah Dikirim</a>
                    <a class="nav-link" href="/rental-belum-dikirim">Belum Dikirim</a>
                    <a class="nav-link" href="/rental-sudah-lunas">Sudah Lunas</a>
                    <a class="nav-link" href="/rental-belum-lunas">Belum Lunas</a>
                </nav>
            </div>

            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#pengembalian"
                aria-expanded="false" aria-controls="collapseLayouts">
                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                Pengembalian
                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
            </a>
            <div class="collapse" id="pengembalian" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                <nav class="sb-sidenav-menu-nested nav">
                    <a class="nav-link" href="/pengembalian-sudah-dikirim">Sudah Dikirim</a>
                    <a class="nav-link" href="/pengembalian-belum-dikirim">Belum Dikirim</a>
                    <a class="nav-link" href="/pengembalian-terlambat">Terlambat</a>
                </nav>
            </div>
        </div>
    </div>
    <div class="sb-sidenav-footer">
        Create with love
    </div>
</nav>
<?php /**PATH D:\Laravel\sunnycosrent-backend\resources\views/partials/sidenav.blade.php ENDPATH**/ ?>